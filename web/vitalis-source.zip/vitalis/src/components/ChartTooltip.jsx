import { useTheme } from '../store/theme.js';

// Themed replacement for the default Recharts tooltip.
// `valueFormat` is applied to each numeric value.
export default function ChartTooltip({ active, payload, label, valueFormat = (v) => v }) {
  const t = useTheme();
  if (!active || !payload || !payload.length) return null;
  return (
    <div
      className="rounded-lg px-3 py-2 text-xs border backdrop-blur-md"
      style={{
        background: t.panel + 'EE',
        borderColor: t.line,
        color: t.ink,
        boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
      }}
    >
      {label && <div className="font-semibold mb-1">{label}</div>}
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2">
          <span
            className="w-2 h-2 rounded-full inline-block"
            style={{ background: p.color || p.fill }}
          />
          <span style={{ color: t.inkSoft }}>{p.name}:</span>
          <span className="font-medium">{valueFormat(p.value)}</span>
        </div>
      ))}
    </div>
  );
}
