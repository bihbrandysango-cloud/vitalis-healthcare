import { LayoutDashboard, PlusCircle, Settings as SettingsIcon } from 'lucide-react';
import { useTheme } from '../store/theme.js';

const ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'add',       label: 'Add',       icon: PlusCircle },
  { id: 'settings',  label: 'Settings',  icon: SettingsIcon },
];

export default function BottomNav({ current, onNav }) {
  const t = useTheme();
  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 flex justify-around px-2 py-2 border-t backdrop-blur-xl"
      style={{ background: t.panel + 'DD', borderColor: t.line }}
    >
      {ITEMS.map((item) => {
        const active = current === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onNav(item.id)}
            className="flex flex-col items-center gap-1 px-4 py-1.5 rounded-lg flex-1"
            style={{ color: active ? t.primary : t.inkMuted }}
          >
            <item.icon size={20} strokeWidth={active ? 2 : 1.5} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
