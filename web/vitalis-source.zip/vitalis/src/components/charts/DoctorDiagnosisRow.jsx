import { useMemo } from 'react';
import {
  ResponsiveContainer, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Cell,
} from 'recharts';
import { useTheme } from '../../store/theme.js';
import { DIAGNOSES } from '../../data/constants.js';
import { monthKey, monthLabel, fmtMoney, fmtMoneyShort } from '../../utils/format.js';
import Panel from '../Panel.jsx';
import ChartTooltip from '../ChartTooltip.jsx';

export default function DoctorDiagnosisRow({ records, filters, setFilters }) {
  const t = useTheme();

  const bySpecialty = useMemo(() => {
    const map = new Map();
    records.forEach((r) => {
      const v = map.get(r.specialty) || { specialty: r.specialty, count: 0, revenue: 0 };
      v.count += 1;
      v.revenue += r.amount;
      map.set(r.specialty, v);
    });
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
  }, [records]);

  const byDiagnosis = useMemo(() => {
    const map = new Map(DIAGNOSES.map((d) => [d.label, 0]));
    records.forEach((r) => map.set(r.diagnosis, (map.get(r.diagnosis) || 0) + 1));
    return Array.from(map, ([diagnosis, count]) => ({ diagnosis, count }))
      .sort((a, b) => b.count - a.count);
  }, [records]);

  // Diagnosis trend by month — line per diagnosis
  const diagnosisTrend = useMemo(() => {
    const months = Array.from(new Set(records.map((r) => monthKey(r.date)))).sort();
    return months.map((m) => {
      const row = { month: m, label: monthLabel(m) };
      DIAGNOSES.forEach((d) => { row[d.label] = 0; });
      records.forEach((r) => {
        if (monthKey(r.date) === m) row[r.diagnosis] = (row[r.diagnosis] || 0) + 1;
      });
      return row;
    });
  }, [records]);

  const colors = [t.primary, t.accent, t.accent3, t.accent2, t.accent4, t.success];

  const toggle = (key, val) =>
    setFilters({ ...filters, [key]: filters[key] === val ? null : val });

  return (
    <>
      <div className="grid lg:grid-cols-2 gap-6">
        <Panel title="Revenue by specialty" subtitle="Click to filter">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={bySpecialty} margin={{ top: 10, right: 10, bottom: 40, left: -10 }}>
              <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
              <XAxis
                dataKey="specialty" stroke={t.inkMuted}
                tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={60}
              />
              <YAxis
                stroke={t.inkMuted} tick={{ fontSize: 11 }}
                tickFormatter={(v) => fmtMoneyShort(v)}
              />
              <Tooltip content={<ChartTooltip valueFormat={fmtMoney} />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
              <Bar
                dataKey="revenue" radius={[6, 6, 0, 0]}
                onClick={(d) => setFilters({ ...filters, specialty: filters.specialty === d.specialty ? 'all' : d.specialty })}
                cursor="pointer"
              >
                {bySpecialty.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={colors[i % colors.length]}
                    opacity={
                      filters.specialty && filters.specialty !== 'all' && filters.specialty !== entry.specialty
                        ? 0.3 : 1
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>

        <Panel title="Top diagnoses" subtitle="Click to filter">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={byDiagnosis} layout="vertical" margin={{ top: 5, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid strokeDasharray="2 4" stroke={t.line} horizontal={false} />
              <XAxis type="number" stroke={t.inkMuted} tick={{ fontSize: 10 }} />
              <YAxis dataKey="diagnosis" type="category" stroke={t.inkMuted} tick={{ fontSize: 10 }} width={100} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
              <Bar
                dataKey="count" radius={[0, 6, 6, 0]}
                onClick={(d) => toggle('diagnosis', d.diagnosis)} cursor="pointer"
              >
                {byDiagnosis.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={t.accent3}
                    opacity={filters.diagnosis && filters.diagnosis !== entry.diagnosis ? 0.3 : 1}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      <Panel title="Diagnosis trend over time" subtitle="Monthly cases per condition">
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={diagnosisTrend} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="label" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <Tooltip content={<ChartTooltip />} />
            {DIAGNOSES.map((d, i) => (
              <Line
                key={d.label}
                type="monotone"
                dataKey={d.label}
                stroke={colors[i % colors.length]}
                strokeWidth={2}
                dot={false}
                name={d.label}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
        <div className="flex flex-wrap gap-3 justify-center mt-2 text-[11px]" style={{ color: t.inkSoft }}>
          {DIAGNOSES.map((d, i) => (
            <div key={d.label} className="flex items-center gap-1.5">
              <span
                className="w-2 h-2 rounded-sm inline-block"
                style={{ background: colors[i % colors.length] }}
              />
              {d.label}
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}
