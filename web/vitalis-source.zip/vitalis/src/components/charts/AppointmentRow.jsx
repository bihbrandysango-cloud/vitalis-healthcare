import { useMemo } from 'react';
import {
  ResponsiveContainer, BarChart, Bar, LineChart, Line,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts';
import { useTheme } from '../../store/theme.js';
import { STATUSES } from '../../data/constants.js';
import { monthKey, monthLabel, weekdayShort } from '../../utils/format.js';
import Panel from '../Panel.jsx';
import ChartTooltip from '../ChartTooltip.jsx';

export default function AppointmentRow({ records, filters, setFilters }) {
  const t = useTheme();
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const byWeekday = useMemo(() => {
    const map = new Map(days.map((d) => [d, 0]));
    records.forEach((r) => {
      const d = weekdayShort(r.date);
      map.set(d, map.get(d) + 1);
    });
    return days.map((d) => ({ day: d, count: map.get(d) }));
  }, [records]);

  const byStatus = useMemo(() => {
    const map = new Map(STATUSES.map((s) => [s, 0]));
    records.forEach((r) => map.set(r.status, map.get(r.status) + 1));
    return Array.from(map, ([status, value]) => ({ status, value }));
  }, [records]);

  const monthlyNoShows = useMemo(() => {
    const map = new Map();
    records.forEach((r) => {
      const k = monthKey(r.date);
      const v = map.get(k) || { month: k, label: monthLabel(k), noShows: 0 };
      if (r.status === 'No-show') v.noShows += 1;
      map.set(k, v);
    });
    return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
  }, [records]);

  const statusColor = (s) =>
    s === 'Completed' ? t.success : s === 'No-show' ? t.danger : t.warning;

  const toggle = (key, val) =>
    setFilters({ ...filters, [key]: filters[key] === val ? null : val });

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <Panel title="Appointments by weekday">
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={byWeekday} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="day" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <Tooltip content={<ChartTooltip />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
            <Bar dataKey="count" fill={t.accent2} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Panel>

      <Panel title="Appointment status" subtitle="Click to filter">
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={byStatus} dataKey="value"
              cx="50%" cy="50%" innerRadius={40} outerRadius={80} paddingAngle={3}
              onClick={(d) => toggle('status', d.status)} cursor="pointer"
            >
              {byStatus.map((entry, i) => (
                <Cell
                  key={i}
                  fill={statusColor(entry.status)}
                  stroke={filters.status === entry.status ? t.ink : 'transparent'}
                  strokeWidth={filters.status === entry.status ? 2 : 0}
                  opacity={filters.status && filters.status !== entry.status ? 0.35 : 1}
                />
              ))}
            </Pie>
            <Tooltip content={<ChartTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        <div className="flex justify-center gap-3 text-[11px] mt-1" style={{ color: t.inkSoft }}>
          {byStatus.map((s) => (
            <div key={s.status} className="flex items-center gap-1">
              <span
                className="w-2 h-2 rounded-sm inline-block"
                style={{ background: statusColor(s.status) }}
              />
              {s.status}
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="No-show trend">
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={monthlyNoShows} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="label" stroke={t.inkMuted} tick={{ fontSize: 10 }} />
            <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <Tooltip content={<ChartTooltip />} />
            <Line
              type="monotone" dataKey="noShows"
              stroke={t.danger} strokeWidth={2.5}
              dot={{ fill: t.danger, r: 3 }} name="No-shows"
            />
          </LineChart>
        </ResponsiveContainer>
      </Panel>
    </div>
  );
}
