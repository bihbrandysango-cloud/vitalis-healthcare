import { useMemo } from 'react';
import {
  ResponsiveContainer, PieChart, Pie, Cell,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
} from 'recharts';
import { useTheme } from '../../store/theme.js';
import { CITIES, INSURERS } from '../../data/constants.js';
import Panel from '../Panel.jsx';
import ChartTooltip from '../ChartTooltip.jsx';

export default function DemographicsRow({ records, filters, setFilters }) {
  const t = useTheme();

  const byGender = useMemo(() => {
    const m = { F: 0, M: 0 };
    records.forEach((r) => { m[r.gender] += 1; });
    return [
      { name: 'Female', value: m.F, gender: 'F' },
      { name: 'Male',   value: m.M, gender: 'M' },
    ];
  }, [records]);

  const byCity = useMemo(() => {
    const map = new Map(CITIES.map((c) => [c, 0]));
    records.forEach((r) => map.set(r.city, (map.get(r.city) || 0) + 1));
    return Array.from(map, ([city, count]) => ({ city, count }))
      .sort((a, b) => b.count - a.count);
  }, [records]);

  const byInsurance = useMemo(() => {
    const map = new Map(INSURERS.map((c) => [c, 0]));
    records.forEach((r) => map.set(r.insurance, (map.get(r.insurance) || 0) + 1));
    return Array.from(map, ([name, value]) => ({ name, value }));
  }, [records]);

  const toggle = (key, val) =>
    setFilters({ ...filters, [key]: filters[key] === val ? null : val });

  const colors = [t.primary, t.accent, t.accent3, t.accent2, t.accent4];

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <Panel title="Gender distribution" subtitle="Click a slice to filter">
        <ResponsiveContainer width="100%" height={240}>
          <PieChart>
            <Pie
              data={byGender} dataKey="value"
              cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={3}
              onClick={(d) => toggle('gender', d.gender)} cursor="pointer"
            >
              {byGender.map((entry, i) => (
                <Cell
                  key={i}
                  fill={i === 0 ? t.primary : t.accent}
                  stroke={filters.gender === entry.gender ? t.ink : 'transparent'}
                  strokeWidth={filters.gender === entry.gender ? 2 : 0}
                  opacity={filters.gender && filters.gender !== entry.gender ? 0.35 : 1}
                />
              ))}
            </Pie>
            <Tooltip content={<ChartTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        <div className="flex justify-center gap-4 text-xs" style={{ color: t.inkSoft }}>
          {byGender.map((g, i) => (
            <div key={g.name} className="flex items-center gap-1.5">
              <span
                className="w-2.5 h-2.5 rounded-sm inline-block"
                style={{ background: i === 0 ? t.primary : t.accent }}
              />
              {g.name} · {g.value}
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Patients by city">
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={byCity} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="city" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <Tooltip content={<ChartTooltip />} cursor={{ fill: t.panelMuted, opacity: 0.5 }} />
            <Bar
              dataKey="count" radius={[6, 6, 0, 0]}
              onClick={(d) => toggle('city', d.city)} cursor="pointer"
            >
              {byCity.map((entry, i) => (
                <Cell
                  key={i}
                  fill={t.primary}
                  opacity={filters.city && filters.city !== entry.city ? 0.3 : 1}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Panel>

      <Panel title="Insurance provider mix">
        <ResponsiveContainer width="100%" height={240}>
          <PieChart>
            <Pie
              data={byInsurance} dataKey="value"
              cx="50%" cy="50%" outerRadius={85}
              onClick={(d) => toggle('insurance', d.name)} cursor="pointer"
            >
              {byInsurance.map((entry, i) => (
                <Cell
                  key={i}
                  fill={colors[i % colors.length]}
                  stroke={filters.insurance === entry.name ? t.ink : 'transparent'}
                  strokeWidth={filters.insurance === entry.name ? 2 : 0}
                  opacity={filters.insurance && filters.insurance !== entry.name ? 0.35 : 1}
                />
              ))}
            </Pie>
            <Tooltip content={<ChartTooltip />} />
            <Legend wrapperStyle={{ fontSize: 11, color: t.inkSoft }} />
          </PieChart>
        </ResponsiveContainer>
      </Panel>
    </div>
  );
}
