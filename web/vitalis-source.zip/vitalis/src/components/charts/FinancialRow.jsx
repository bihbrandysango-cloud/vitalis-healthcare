import { useMemo } from 'react';
import {
  ResponsiveContainer, AreaChart, Area,
  BarChart, Bar, ComposedChart, Line, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts';
import { useTheme } from '../../store/theme.js';
import { CITIES } from '../../data/constants.js';
import { monthKey, monthLabel, fmtMoney, fmtMoneyShort } from '../../utils/format.js';
import Panel from '../Panel.jsx';
import ChartTooltip from '../ChartTooltip.jsx';

export default function FinancialRow({ records, filters, setFilters }) {
  const t = useTheme();

  const monthly = useMemo(() => {
    const map = new Map();
    records.forEach((r) => {
      const k = monthKey(r.date);
      const v = map.get(k) || { month: k, label: monthLabel(k), revenue: 0, expense: 0 };
      v.revenue += r.amount;
      v.expense += r.expense;
      map.set(k, v);
    });
    return Array.from(map.values()).sort((a, b) => a.month.localeCompare(b.month));
  }, [records]);

  const byClinic = useMemo(() => {
    const map = new Map(CITIES.map((c) => [c, 0]));
    records.forEach((r) => map.set(r.city, (map.get(r.city) || 0) + r.amount));
    return Array.from(map, ([clinic, revenue]) => ({ clinic, revenue }))
      .sort((a, b) => b.revenue - a.revenue);
  }, [records]);

  const toggleCity = (city) =>
    setFilters({ ...filters, city: filters.city === city ? null : city });

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <Panel title="Revenue trend" subtitle="Monthly billed amount" className="lg:col-span-2">
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={monthly} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={t.primary} stopOpacity={0.4} />
                <stop offset="100%" stopColor={t.primary} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="label" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <YAxis
              stroke={t.inkMuted} tick={{ fontSize: 11 }}
              tickFormatter={(v) => fmtMoneyShort(v)}
            />
            <Tooltip content={<ChartTooltip valueFormat={fmtMoney} />} />
            <Area
              type="monotone" dataKey="revenue"
              stroke={t.primary} strokeWidth={2.5}
              fill="url(#revGrad)" name="Revenue"
            />
          </AreaChart>
        </ResponsiveContainer>
      </Panel>

      <Panel title="Revenue by clinic">
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={byClinic} layout="vertical" margin={{ top: 5, right: 20, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} horizontal={false} />
            <XAxis
              type="number" stroke={t.inkMuted} tick={{ fontSize: 10 }}
              tickFormatter={(v) => fmtMoneyShort(v)}
            />
            <YAxis dataKey="clinic" type="category" stroke={t.inkMuted} tick={{ fontSize: 11 }} width={70} />
            <Tooltip content={<ChartTooltip valueFormat={fmtMoney} />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
            <Bar dataKey="revenue" radius={[0, 6, 6, 0]} onClick={(d) => toggleCity(d.clinic)} cursor="pointer">
              {byClinic.map((entry, i) => (
                <Cell
                  key={i}
                  fill={t.accent}
                  opacity={filters.city && filters.city !== entry.clinic ? 0.3 : 1}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Panel>

      <Panel title="Revenue vs expense" subtitle="Monthly comparison" className="lg:col-span-3">
        <ResponsiveContainer width="100%" height={240}>
          <ComposedChart data={monthly} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="label" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <YAxis
              stroke={t.inkMuted} tick={{ fontSize: 11 }}
              tickFormatter={(v) => fmtMoneyShort(v)}
            />
            <Tooltip content={<ChartTooltip valueFormat={fmtMoney} />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
            <Bar dataKey="revenue" fill={t.primary} radius={[6, 6, 0, 0]} name="Revenue" />
            <Bar dataKey="expense" fill={t.accent2} radius={[6, 6, 0, 0]} name="Expense" />
            <Line type="monotone" dataKey="revenue" stroke={t.primary} strokeWidth={2} dot={false} name="Revenue trend" />
          </ComposedChart>
        </ResponsiveContainer>
      </Panel>
    </div>
  );
}
