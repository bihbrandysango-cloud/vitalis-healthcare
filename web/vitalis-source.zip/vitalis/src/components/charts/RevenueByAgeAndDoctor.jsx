import { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Cell,
} from 'recharts';
import { useTheme } from '../../store/theme.js';
import { AGE_ORDER } from '../../data/constants.js';
import { ageGroup, fmtMoney, fmtMoneyShort, fmtPct } from '../../utils/format.js';
import Panel from '../Panel.jsx';
import ChartTooltip from '../ChartTooltip.jsx';

export default function RevenueByAgeAndDoctor({ records, filters, setFilters }) {
  const t = useTheme();

  const byAgeGroup = useMemo(() => {
    const map = new Map(AGE_ORDER.map((g) => [g, { revenue: 0, count: 0 }]));
    records.forEach((r) => {
      const g = ageGroup(r.age);
      const v = map.get(g);
      v.revenue += r.amount;
      v.count += 1;
    });
    return AGE_ORDER.map((g) => ({ ageGroup: g, ...map.get(g) }));
  }, [records]);

  const doctorPerf = useMemo(() => {
    const map = new Map();
    records.forEach((r) => {
      const v = map.get(r.doctor) || { doctor: r.doctor, completed: 0, noShow: 0, revenue: 0, total: 0 };
      v.total += 1;
      v.revenue += r.amount;
      if (r.status === 'Completed') v.completed += 1;
      if (r.status === 'No-show') v.noShow += 1;
      map.set(r.doctor, v);
    });
    return Array.from(map.values())
      .map((d) => ({
        ...d,
        completionRate: d.total ? d.completed / d.total : 0,
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 6);
  }, [records]);

  const toggleAge = (ag) =>
    setFilters({ ...filters, ageGroup: filters.ageGroup === ag ? null : ag });

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <Panel title="Revenue by age group" subtitle="Click to filter">
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={byAgeGroup} margin={{ top: 10, right: 10, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
            <XAxis dataKey="ageGroup" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
            <YAxis
              stroke={t.inkMuted} tick={{ fontSize: 11 }}
              tickFormatter={(v) => fmtMoneyShort(v)}
            />
            <Tooltip content={<ChartTooltip valueFormat={fmtMoney} />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
            <Bar
              dataKey="revenue" radius={[6, 6, 0, 0]}
              onClick={(d) => toggleAge(d.ageGroup)} cursor="pointer"
            >
              {byAgeGroup.map((entry, i) => (
                <Cell
                  key={i}
                  fill={t.accent4}
                  opacity={filters.ageGroup && filters.ageGroup !== entry.ageGroup ? 0.3 : 1}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </Panel>

      <Panel title="Doctor efficiency rankings" subtitle="Top earners and completion rates">
        <div className="space-y-2.5 mt-1">
          {doctorPerf.map((d, i) => (
            <motion.div
              key={d.doctor}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center gap-3"
            >
              <span className="text-xs font-mono w-5" style={{ color: t.inkMuted }}>
                {String(i + 1).padStart(2, '0')}
              </span>
              <span className="text-sm flex-1 truncate" style={{ color: t.ink }}>{d.doctor}</span>
              <span className="text-xs font-mono" style={{ color: t.inkSoft }}>
                {fmtMoney(d.revenue)}
              </span>
              <div className="w-20 h-1.5 rounded-full overflow-hidden" style={{ background: t.panelMuted }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${d.completionRate * 100}%` }}
                  transition={{ duration: 0.8, delay: i * 0.05 }}
                  className="h-full rounded-full"
                  style={{ background: t.success }}
                />
              </div>
              <span className="text-[10px] font-mono w-10 text-right" style={{ color: t.inkMuted }}>
                {fmtPct(d.completionRate)}
              </span>
            </motion.div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
