import { useMemo } from 'react';
import {
  ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts';
import { useTheme } from '../../store/theme.js';
import { CHRONIC_CONDITIONS, DIAGNOSES, CITIES } from '../../data/constants.js';
import { bpCategory, bmiCategory, riskSegment } from '../../data/generator.js';
import Panel from '../Panel.jsx';
import ChartTooltip from '../ChartTooltip.jsx';

const BP_ORDER  = ['Normal', 'Elevated', 'Stage 1', 'Stage 2', 'Crisis'];
const BMI_ORDER = ['Underweight', 'Healthy', 'Overweight', 'Obese'];
const RISK_ORDER = ['Low', 'Moderate', 'High', 'Critical'];

export default function HealthProfileRow({ records, filters, setFilters }) {
  const t = useTheme();

  const byBP = useMemo(() => {
    const map = new Map(BP_ORDER.map((b) => [b, 0]));
    records.forEach((r) => {
      const c = bpCategory(r.systolic, r.diastolic);
      map.set(c, map.get(c) + 1);
    });
    return BP_ORDER.map((b) => ({ category: b, count: map.get(b) }));
  }, [records]);

  const byBMI = useMemo(() => {
    const map = new Map(BMI_ORDER.map((b) => [b, 0]));
    records.forEach((r) => {
      const c = bmiCategory(r.bmi);
      map.set(c, map.get(c) + 1);
    });
    return BMI_ORDER.map((b) => ({ category: b, count: map.get(b) }));
  }, [records]);

  const byChronic = useMemo(() => {
    const map = new Map(CHRONIC_CONDITIONS.map((c) => [c, 0]));
    records.forEach((r) => map.set(r.chronicCondition, map.get(r.chronicCondition) + 1));
    return CHRONIC_CONDITIONS.map((c) => ({ condition: c, value: map.get(c) }));
  }, [records]);

  const byRisk = useMemo(() => {
    const map = new Map(RISK_ORDER.map((r) => [r, 0]));
    records.forEach((r) => {
      const seg = riskSegment(r.riskScore);
      map.set(seg, map.get(seg) + 1);
    });
    return RISK_ORDER.map((r) => ({ segment: r, count: map.get(r) }));
  }, [records]);

  // Heatmap: diagnosis × clinic location, with deeper saturation = more cases
  const heatmap = useMemo(() => {
    const cells = [];
    let max = 0;
    DIAGNOSES.forEach((d) => {
      CITIES.forEach((c) => {
        const count = records.filter((r) => r.diagnosis === d.label && r.city === c).length;
        if (count > max) max = count;
        cells.push({ diagnosis: d.label, code: d.code, city: c, count });
      });
    });
    return { cells, max };
  }, [records]);

  // BP color ramp from green → red
  const bpColor = (cat) => ({
    'Normal':    t.success,
    'Elevated':  t.accent2,
    'Stage 1':   t.warning,
    'Stage 2':   t.accent,
    'Crisis':    t.danger,
  }[cat] || t.primary);

  const riskColor = (seg) => ({
    'Low':      t.success,
    'Moderate': t.accent2,
    'High':     t.accent,
    'Critical': t.danger,
  }[seg] || t.primary);

  const chronicColors = [t.danger, t.accent2, t.accent, t.accent3, t.primarySoft];

  const toggleChronic = (val) =>
    setFilters({ ...filters, chronic: filters.chronic === val ? null : val });

  // Compute a single heatmap cell color (white → primary in light, panel → primary in dark)
  const heatColor = (count) => {
    if (count === 0) return t.panelMuted;
    const ratio = count / Math.max(1, heatmap.max);
    // Use the primary color with varying alpha
    const alpha = Math.round((0.15 + ratio * 0.75) * 255).toString(16).padStart(2, '0');
    return t.primary + alpha;
  };

  return (
    <>
      <div className="grid lg:grid-cols-2 gap-6">
        <Panel title="Blood pressure categories" subtitle="Per ACC/AHA 2017 guidelines">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={byBP} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
              <XAxis dataKey="category" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
              <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {byBP.map((entry, i) => (
                  <Cell key={i} fill={bpColor(entry.category)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>

        <Panel title="BMI ranges">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={byBMI} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
              <XAxis dataKey="category" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
              <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {byBMI.map((entry, i) => {
                  const c = entry.category === 'Healthy' ? t.success
                    : entry.category === 'Underweight' ? t.accent3
                    : entry.category === 'Overweight' ? t.accent2
                    : t.danger;
                  return <Cell key={i} fill={c} />;
                })}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Panel title="Chronic disease distribution" subtitle="Click to filter">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={byChronic} dataKey="value" nameKey="condition"
                cx="50%" cy="50%" innerRadius={50} outerRadius={95} paddingAngle={2}
                onClick={(d) => toggleChronic(d.condition)} cursor="pointer"
              >
                {byChronic.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={chronicColors[i % chronicColors.length]}
                    stroke={filters.chronic === entry.condition ? t.ink : 'transparent'}
                    strokeWidth={filters.chronic === entry.condition ? 2 : 0}
                    opacity={filters.chronic && filters.chronic !== entry.condition ? 0.35 : 1}
                  />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 justify-center text-[11px]" style={{ color: t.inkSoft }}>
            {byChronic.map((c, i) => (
              <div key={c.condition} className="flex items-center gap-1.5">
                <span
                  className="w-2 h-2 rounded-sm inline-block"
                  style={{ background: chronicColors[i % chronicColors.length] }}
                />
                {c.condition}
              </div>
            ))}
          </div>
        </Panel>

        <Panel title="Risk score segmentation" subtitle="Composite from age, vitals, diagnosis">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={byRisk} margin={{ top: 10, right: 10, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="2 4" stroke={t.line} vertical={false} />
              <XAxis dataKey="segment" stroke={t.inkMuted} tick={{ fontSize: 11 }} />
              <YAxis stroke={t.inkMuted} tick={{ fontSize: 11 }} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: t.panelMuted, opacity: 0.4 }} />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {byRisk.map((entry, i) => (
                  <Cell key={i} fill={riskColor(entry.segment)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      {/* Diagnosis × Clinic heatmap */}
      <Panel title="Diagnosis frequency heatmap" subtitle="Cases by diagnosis × clinic location">
        <div className="overflow-x-auto">
          <table className="w-full border-separate" style={{ borderSpacing: '4px' }}>
            <thead>
              <tr>
                <th></th>
                {CITIES.map((c) => (
                  <th
                    key={c}
                    className="text-[10px] uppercase px-2 pb-2"
                    style={{ color: t.inkMuted, letterSpacing: '0.1em', fontWeight: 500 }}
                  >
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {DIAGNOSES.map((d) => (
                <tr key={d.code}>
                  <td
                    className="text-xs pr-3 text-right whitespace-nowrap"
                    style={{ color: t.inkSoft }}
                  >
                    <span className="font-mono text-[10px] opacity-60 mr-1">{d.code}</span>
                    {d.label}
                  </td>
                  {CITIES.map((c) => {
                    const cell = heatmap.cells.find(
                      (h) => h.diagnosis === d.label && h.city === c
                    );
                    return (
                      <td key={c} className="p-0">
                        <div
                          className="rounded-md flex items-center justify-center text-xs font-medium aspect-[3/2] min-h-[44px]"
                          style={{
                            background: heatColor(cell.count),
                            color: cell.count / heatmap.max > 0.5 ? 'white' : t.inkSoft,
                          }}
                        >
                          {cell.count || '—'}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}
