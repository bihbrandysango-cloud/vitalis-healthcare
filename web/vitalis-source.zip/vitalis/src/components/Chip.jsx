import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useTheme } from '../store/theme.js';

export default function Chip({ label, onRemove }) {
  const t = useTheme();
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs border"
      style={{
        background: t.primarySoft + '20',
        borderColor: t.primary + '40',
        color: t.primary,
      }}
    >
      <span className="font-medium">{label}</span>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="hover:opacity-60"
          aria-label={`Remove filter: ${label}`}
        >
          <X size={12} />
        </button>
      )}
    </motion.div>
  );
}
