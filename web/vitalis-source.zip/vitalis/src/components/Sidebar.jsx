import { motion } from 'framer-motion';
import { LayoutDashboard, PlusCircle, Settings as SettingsIcon, Stethoscope } from 'lucide-react';
import { useTheme } from '../store/theme.js';

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'add',       label: 'Add Record', icon: PlusCircle },
  { id: 'settings',  label: 'Settings', icon: SettingsIcon },
];

export default function Sidebar({ current, onNav }) {
  const t = useTheme();
  return (
    <aside
      className="hidden md:flex flex-col w-60 px-5 py-7 border-r shrink-0"
      style={{ background: t.panel, borderColor: t.line }}
    >
      <div className="flex items-center gap-2 mb-10">
        <div
          className="w-9 h-9 rounded-xl flex items-center justify-center"
          style={{ background: t.primary }}
        >
          <Stethoscope size={18} color="white" strokeWidth={2} />
        </div>
        <div>
          <div
            className="text-base"
            style={{
              color: t.ink,
              fontFamily: '"Fraunces", Georgia, serif',
              fontWeight: 600,
            }}
          >
            Vitalis
          </div>
          <div
            className="text-[10px] uppercase"
            style={{ color: t.inkMuted, letterSpacing: '0.15em' }}
          >
            Health Analytics
          </div>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {NAV_ITEMS.map((item) => {
          const active = current === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNav(item.id)}
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all relative"
              style={{
                background: active ? t.primary + '15' : 'transparent',
                color: active ? t.primary : t.inkSoft,
                fontWeight: active ? 600 : 400,
              }}
            >
              {active && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-r"
                  style={{ background: t.primary }}
                />
              )}
              <item.icon size={16} strokeWidth={1.75} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="mt-auto pt-6 border-t" style={{ borderColor: t.line }}>
        <div
          className="text-[10px] uppercase mb-2"
          style={{ color: t.inkMuted, letterSpacing: '0.15em' }}
        >
          Period
        </div>
        <div className="text-xs" style={{ color: t.inkSoft }}>Last 90 days</div>
      </div>
    </aside>
  );
}
