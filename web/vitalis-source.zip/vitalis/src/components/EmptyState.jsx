import { Inbox } from 'lucide-react';
import { useTheme } from '../store/theme.js';

export default function EmptyState({ icon: Icon = Inbox, title = 'No data', subtitle }) {
  const t = useTheme();
  return (
    <div
      className="flex flex-col items-center justify-center py-10 text-center"
      style={{ color: t.inkMuted }}
    >
      <Icon size={28} strokeWidth={1.5} className="opacity-60 mb-2" />
      <div className="text-sm font-medium" style={{ color: t.inkSoft }}>{title}</div>
      {subtitle && <div className="text-xs mt-1 max-w-xs">{subtitle}</div>}
    </div>
  );
}
