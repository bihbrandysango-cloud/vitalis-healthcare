import { useTheme } from '../store/theme.js';

export default function Select({ value, onChange, options, label }) {
  const t = useTheme();
  return (
    <div className="flex flex-col">
      {label && (
        <label
          className="text-[10px] uppercase mb-1"
          style={{ color: t.inkMuted, letterSpacing: '0.1em' }}
        >
          {label}
        </label>
      )}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="px-3 py-2 rounded-lg text-sm border outline-none cursor-pointer"
        style={{
          background: t.panel,
          borderColor: t.line,
          color: t.ink,
          colorScheme: t.mode, // tells the browser to render native dropdown chrome in the right theme
        }}
      >
        {options.map((o) => {
          const v = typeof o === 'object' ? o.value : o;
          const l = typeof o === 'object' ? o.label : o;
          return (
            <option
              key={v}
              value={v}
              style={{ background: t.panel, color: t.ink }}
            >
              {l}
            </option>
          );
        })}
      </select>
    </div>
  );
}
