import { useState, useMemo } from 'react';
import { ChevronUp, ChevronDown, Search, Trash2, X } from 'lucide-react';
import { useTheme } from '../store/theme.js';
import { fmtMoney } from '../utils/format.js';
import EmptyState from './EmptyState.jsx';

// Each column declares whether it's filterable and how to render its filter dropdown.
// `filter: 'select'` builds the dropdown from distinct values in the data;
// `filter: 'gender'` uses fixed Female/Male options.
const COLUMNS = [
  { id: 'date',      label: 'Date',      filter: null,     align: 'left'  },
  { id: 'patient',   label: 'Patient',   filter: null,     align: 'left'  },
  { id: 'gender',    label: 'Sex',       filter: 'gender', align: 'left'  },
  { id: 'age',       label: 'Age',       filter: null,     align: 'left'  },
  { id: 'diagnosis', label: 'Diagnosis', filter: 'select', align: 'left'  },
  { id: 'doctor',    label: 'Doctor',    filter: 'select', align: 'left'  },
  { id: 'city',      label: 'City',      filter: 'select', align: 'left'  },
  { id: 'amount',    label: 'Amount',    filter: null,     align: 'right' },
  { id: 'status',    label: 'Status',    filter: 'select', align: 'left'  },
];

const PAGE_SIZE = 8;

export default function RecordsTable({ records, onDelete }) {
  const t = useTheme();
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState({ col: 'date', dir: 'desc' });
  const [page, setPage] = useState(0);
  // Per-column filter values, keyed by column id. Missing key = no filter.
  const [colFilters, setColFilters] = useState({});
  // Set of selected row IDs (for bulk delete)
  const [selected, setSelected] = useState(new Set());
  // Two-click confirmation state for the bulk delete icon
  const [confirmBulkDelete, setConfirmBulkDelete] = useState(false);

  // Distinct values for each filterable select column. Computed once per
  // records list change.
  const distinctValues = useMemo(() => {
    const out = {};
    COLUMNS.forEach((c) => {
      if (c.filter === 'select') {
        const set = new Set();
        records.forEach((r) => { if (r[c.id] != null && r[c.id] !== '') set.add(r[c.id]); });
        out[c.id] = Array.from(set).sort();
      }
    });
    return out;
  }, [records]);

  // Apply search + per-column filters
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return records.filter((r) => {
      // Free-text search
      if (q && !(
        r.patient.toLowerCase().includes(q) ||
        r.diagnosis.toLowerCase().includes(q) ||
        r.doctor.toLowerCase().includes(q) ||
        r.city.toLowerCase().includes(q)
      )) return false;
      // Per-column filters
      for (const [col, val] of Object.entries(colFilters)) {
        if (val && r[col] !== val) return false;
      }
      return true;
    });
  }, [records, search, colFilters]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    arr.sort((a, b) => {
      const av = a[sortBy.col], bv = b[sortBy.col];
      if (av < bv) return sortBy.dir === 'asc' ? -1 : 1;
      if (av > bv) return sortBy.dir === 'asc' ? 1 : -1;
      return 0;
    });
    return arr;
  }, [filtered, sortBy]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const paged = sorted.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const handleSort = (col) => {
    if (sortBy.col === col) setSortBy({ col, dir: sortBy.dir === 'asc' ? 'desc' : 'asc' });
    else setSortBy({ col, dir: 'desc' });
  };

  // Setting `''` clears the filter for that column.
  const updateFilter = (col, val) => {
    const next = { ...colFilters };
    if (val === '') delete next[col];
    else next[col] = val;
    setColFilters(next);
    setPage(0);
  };

  const clearAllColFilters = () => {
    setColFilters({});
    setPage(0);
  };

  // Selection handling
  const toggleSelected = (id) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  };

  const pagedIds = paged.map((r) => r.id);
  const allPagedSelected = pagedIds.length > 0 && pagedIds.every((id) => selected.has(id));
  const someSelected = pagedIds.some((id) => selected.has(id));

  const toggleSelectAllOnPage = () => {
    const next = new Set(selected);
    if (allPagedSelected) {
      pagedIds.forEach((id) => next.delete(id));
    } else {
      pagedIds.forEach((id) => next.add(id));
    }
    setSelected(next);
  };

  // Bulk delete with two-click confirmation
  const handleBulkDelete = () => {
    if (selected.size === 0) return;
    if (!confirmBulkDelete) {
      setConfirmBulkDelete(true);
      setTimeout(() => setConfirmBulkDelete(false), 3000);
      return;
    }
    if (onDelete) onDelete(Array.from(selected));
    setSelected(new Set());
    setConfirmBulkDelete(false);
  };

  const statusColor = (s) =>
    s === 'Completed' ? t.success : s === 'No-show' ? t.danger : t.warning;

  const activeFilterCount = Object.values(colFilters).filter(Boolean).length;

  return (
    <div>
      {/* Toolbar above the table — bulk-delete icon + search + filter-clear */}
      <div className="flex items-center justify-between mb-3 gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          {onDelete && (
            <button
              type="button"
              onClick={handleBulkDelete}
              disabled={selected.size === 0}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-all disabled:opacity-30 disabled:cursor-not-allowed"
              style={{
                background: confirmBulkDelete ? t.danger : (selected.size > 0 ? t.danger + '15' : 'transparent'),
                color: confirmBulkDelete ? 'white' : t.danger,
                borderColor: t.danger + (confirmBulkDelete ? '' : '40'),
              }}
              title={
                selected.size === 0
                  ? 'Select rows to delete'
                  : confirmBulkDelete
                    ? `Click again to confirm deleting ${selected.size} record${selected.size > 1 ? 's' : ''}`
                    : `Delete ${selected.size} selected`
              }
              aria-label="Delete selected records"
            >
              <Trash2 size={13} />
              {selected.size > 0 && (
                <span>
                  {confirmBulkDelete
                    ? `Confirm (${selected.size})`
                    : `${selected.size}`}
                </span>
              )}
            </button>
          )}
          {activeFilterCount > 0 && (
            <button
              type="button"
              onClick={clearAllColFilters}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border"
              style={{ background: t.accent + '15', color: t.accent, borderColor: t.accent + '40' }}
            >
              <X size={11} /> Clear filters
            </button>
          )}
        </div>
        <div className="relative">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2"
            style={{ color: t.inkMuted }}
          />
          <input
            type="search"
            placeholder="Search records…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            className="pl-9 pr-3 py-1.5 rounded-lg text-xs border outline-none w-48"
            style={{ background: t.panel, borderColor: t.line, color: t.ink, colorScheme: t.mode }}
          />
        </div>
      </div>

      {paged.length === 0 ? (
        <EmptyState
          title="No records found"
          subtitle={search || activeFilterCount > 0
            ? 'Try clearing filters or changing your search.'
            : 'Add a record to get started.'}
        />
      ) : (
        <div className="overflow-x-auto -mx-5">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              {/* Row 1: column titles + sort affordance */}
              <tr style={{ background: t.panelMuted }}>
                {onDelete && (
                  <th className="px-3 py-2 w-8" style={{ background: t.panelMuted }}>
                    <input
                      type="checkbox"
                      checked={allPagedSelected}
                      ref={(el) => { if (el) el.indeterminate = someSelected && !allPagedSelected; }}
                      onChange={toggleSelectAllOnPage}
                      className="cursor-pointer"
                      style={{ accentColor: t.primary }}
                      aria-label="Select all rows on page"
                    />
                  </th>
                )}
                {COLUMNS.map((c) => (
                  <th
                    key={c.id}
                    className={`px-4 py-2 text-[10px] uppercase cursor-pointer select-none ${c.align === 'right' ? 'text-right' : 'text-left'}`}
                    style={{ color: t.inkMuted, letterSpacing: '0.12em' }}
                    onClick={() => handleSort(c.id)}
                  >
                    <span className={`inline-flex items-center gap-1 ${c.align === 'right' ? 'justify-end' : ''}`}>
                      {c.label}
                      {sortBy.col === c.id && (
                        sortBy.dir === 'asc' ? <ChevronUp size={11} /> : <ChevronDown size={11} />
                      )}
                    </span>
                  </th>
                ))}
              </tr>

              {/* Row 2: per-column filter dropdowns */}
              <tr style={{ background: t.panelMuted }}>
                {onDelete && <th style={{ background: t.panelMuted }}></th>}
                {COLUMNS.map((c) => (
                  <th key={c.id} className="px-2 pb-2" style={{ background: t.panelMuted }}>
                    {c.filter === 'select' && (
                      <select
                        value={colFilters[c.id] || ''}
                        onChange={(e) => updateFilter(c.id, e.target.value)}
                        className="w-full px-2 py-1 rounded text-[11px] border outline-none cursor-pointer"
                        style={{
                          background: t.panel,
                          borderColor: colFilters[c.id] ? t.primary : t.line,
                          color: t.ink,
                          colorScheme: t.mode,
                        }}
                      >
                        <option value="" style={{ background: t.panel, color: t.ink }}>All</option>
                        {(distinctValues[c.id] || []).map((v) => (
                          <option key={v} value={v} style={{ background: t.panel, color: t.ink }}>{v}</option>
                        ))}
                      </select>
                    )}
                    {c.filter === 'gender' && (
                      <select
                        value={colFilters[c.id] || ''}
                        onChange={(e) => updateFilter(c.id, e.target.value)}
                        className="w-full px-2 py-1 rounded text-[11px] border outline-none cursor-pointer"
                        style={{
                          background: t.panel,
                          borderColor: colFilters[c.id] ? t.primary : t.line,
                          color: t.ink,
                          colorScheme: t.mode,
                        }}
                      >
                        <option value="" style={{ background: t.panel, color: t.ink }}>All</option>
                        <option value="F" style={{ background: t.panel, color: t.ink }}>Female</option>
                        <option value="M" style={{ background: t.panel, color: t.ink }}>Male</option>
                      </select>
                    )}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {paged.map((r) => {
                const sexColor = r.gender === 'F' ? t.accent : t.accent3;
                const isSelected = selected.has(r.id);
                return (
                  <tr
                    key={r.id}
                    className="border-b"
                    style={{
                      borderColor: t.line,
                      background: isSelected ? t.primary + '10' : 'transparent',
                    }}
                  >
                    {onDelete && (
                      <td className="px-3 py-2.5">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelected(r.id)}
                          className="cursor-pointer"
                          style={{ accentColor: t.primary }}
                          aria-label={`Select record for ${r.patient}`}
                        />
                      </td>
                    )}
                    <td className="px-4 py-2.5 font-mono text-xs" style={{ color: t.inkSoft }}>{r.date}</td>
                    <td className="px-4 py-2.5" style={{ color: t.ink }}>{r.patient}</td>
                    <td className="px-4 py-2.5">
                      <span
                        className="inline-flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-semibold"
                        style={{ background: sexColor + '20', color: sexColor }}
                        title={r.gender === 'F' ? 'Female' : 'Male'}
                      >
                        {r.gender}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 font-mono text-xs" style={{ color: t.inkSoft }}>{r.age}</td>
                    <td className="px-4 py-2.5" style={{ color: t.inkSoft }}>{r.diagnosis}</td>
                    <td className="px-4 py-2.5" style={{ color: t.inkSoft }}>{r.doctor}</td>
                    <td className="px-4 py-2.5" style={{ color: t.inkSoft }}>{r.city}</td>
                    <td className="px-4 py-2.5 font-mono text-xs text-right" style={{ color: t.ink }}>
                      {fmtMoney(r.amount)}
                    </td>
                    <td className="px-4 py-2.5">
                      <span
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium"
                        style={{ background: statusColor(r.status) + '20', color: statusColor(r.status) }}
                      >
                        <span className="w-1.5 h-1.5 rounded-full" style={{ background: statusColor(r.status) }} />
                        {r.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-3 text-xs" style={{ color: t.inkSoft }}>
          <span>
            Showing {safePage * PAGE_SIZE + 1}–{Math.min((safePage + 1) * PAGE_SIZE, sorted.length)} of {sorted.length}
          </span>
          <div className="flex gap-1">
            <button
              type="button"
              disabled={safePage === 0}
              onClick={() => setPage(safePage - 1)}
              className="px-3 py-1 rounded border disabled:opacity-40"
              style={{ borderColor: t.line, color: t.inkSoft }}
            >
              Previous
            </button>
            <button
              type="button"
              disabled={safePage >= totalPages - 1}
              onClick={() => setPage(safePage + 1)}
              className="px-3 py-1 rounded border disabled:opacity-40"
              style={{ borderColor: t.line, color: t.inkSoft }}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
