import { motion } from 'framer-motion';
import { useTheme } from '../store/theme.js';

// Reusable card container for charts and content sections.
export default function Panel({ children, className = '', title, subtitle, action, animate = true, padded = true }) {
  const t = useTheme();
  const content = (
    <div
      className={`rounded-2xl border ${className}`}
      style={{
        background: t.panel,
        borderColor: t.line,
        boxShadow: t.mode === 'light'
          ? '0 1px 2px rgba(26,37,48,0.04), 0 8px 24px -12px rgba(26,37,48,0.08)'
          : '0 1px 2px rgba(0,0,0,0.3), 0 8px 24px -12px rgba(0,0,0,0.5)',
      }}
    >
      {(title || action) && (
        <div className="flex items-start justify-between px-5 pt-5 pb-2">
          <div>
            {title && (
              <h3
                className="text-[13px] font-semibold uppercase"
                style={{ color: t.inkSoft, letterSpacing: '0.06em' }}
              >
                {title}
              </h3>
            )}
            {subtitle && (
              <p className="text-xs mt-0.5" style={{ color: t.inkMuted }}>{subtitle}</p>
            )}
          </div>
          {action}
        </div>
      )}
      <div className={padded ? 'px-5 pb-5 pt-2' : ''}>{children}</div>
    </div>
  );

  if (!animate) return content;
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
    >
      {content}
    </motion.div>
  );
}
