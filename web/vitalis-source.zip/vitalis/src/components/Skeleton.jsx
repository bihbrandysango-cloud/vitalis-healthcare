import { useTheme } from '../store/theme.js';

// Pulsing placeholder for loading states. Composed at the call site
// (e.g. <Skeleton className="h-40 w-full" />).
export default function Skeleton({ className = '', style = {} }) {
  const t = useTheme();
  return (
    <div
      className={`rounded-lg animate-pulse ${className}`}
      style={{ background: t.panelMuted, ...style }}
    />
  );
}
