import { motion } from 'framer-motion';
import { useTheme } from '../store/theme.js';
import AnimatedNumber from './AnimatedNumber.jsx';

export default function KpiCard({ icon: Icon, label, value, format, accent }) {
  const t = useTheme();
  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
      className="rounded-2xl p-5 border relative overflow-hidden"
      style={{
        background: t.panel,
        borderColor: t.line,
        boxShadow: t.mode === 'light'
          ? '0 1px 2px rgba(26,37,48,0.04), 0 8px 24px -12px rgba(26,37,48,0.08)'
          : '0 1px 2px rgba(0,0,0,0.3), 0 8px 24px -12px rgba(0,0,0,0.5)',
      }}
    >
      {/* Soft halo in the corner using the accent color */}
      <div
        className="absolute top-0 right-0 w-24 h-24 rounded-full -translate-y-8 translate-x-8 opacity-10"
        style={{ background: accent }}
      />
      <div className="flex items-start justify-between relative">
        <div>
          <div
            className="text-[11px] uppercase font-medium"
            style={{ color: t.inkMuted, letterSpacing: '0.1em' }}
          >
            {label}
          </div>
          <div
            className="text-3xl mt-2"
            style={{
              color: t.ink,
              fontFamily: '"Fraunces", "Playfair Display", Georgia, serif',
              fontWeight: 500,
              letterSpacing: '-0.02em',
            }}
          >
            <AnimatedNumber value={value} format={format} />
          </div>
        </div>
        <div className="p-2 rounded-xl" style={{ background: t.panelMuted, color: accent }}>
          <Icon size={18} strokeWidth={1.75} />
        </div>
      </div>
    </motion.div>
  );
}
