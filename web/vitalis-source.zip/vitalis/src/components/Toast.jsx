import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { useTheme } from '../store/theme.js';

export default function Toast({ message, onClose }) {
  const t = useTheme();
  useEffect(() => {
    const id = setTimeout(onClose, 2600);
    return () => clearTimeout(id);
  }, [onClose]);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.95 }}
      className="fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2"
      style={{ background: t.ink, color: t.bg, fontFamily: '"Inter", sans-serif' }}
      role="status"
      aria-live="polite"
    >
      <Check size={16} />
      <span className="text-sm">{message}</span>
    </motion.div>
  );
}
