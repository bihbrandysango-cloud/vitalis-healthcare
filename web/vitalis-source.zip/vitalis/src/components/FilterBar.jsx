import { useMemo } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Download, Trash2 } from 'lucide-react';
import { useTheme } from '../store/theme.js';
import { SPECIALTIES, CITIES, INSURERS } from '../data/constants.js';
import { monthKey, monthLabel } from '../utils/format.js';
import { VISUAL_FILTER_KEYS, clearVisualFilters } from '../hooks/useFilteredRecords.js';
import Select from './Select.jsx';
import Chip from './Chip.jsx';

const CHIP_LABELS = {
  city:       (v) => `City: ${v}`,
  gender:     (v) => `Gender: ${v === 'F' ? 'Female' : 'Male'}`,
  insurance:  (v) => `Insurance: ${v}`,
  status:     (v) => `Status: ${v}`,
  diagnosis:  (v) => `Diagnosis: ${v}`,
  ageGroup:   (v) => `Age: ${v}`,
  chronic:    (v) => `Condition: ${v}`,
};

export default function FilterBar({ records, filters, setFilters, onCSV }) {
  const t = useTheme();

  // Generate the month dropdown options dynamically from the data
  const monthOptions = useMemo(() => {
    const months = new Set(records.map((r) => monthKey(r.date)));
    return [
      { value: 'all', label: 'All Months' },
      ...Array.from(months).sort().map((m) => ({ value: m, label: monthLabel(m) })),
    ];
  }, [records]);

  // Build the chip list from currently-active visual filters
  const activeChips = useMemo(() => {
    const out = [];
    if (filters.month && filters.month !== 'all') {
      out.push({ key: 'month', label: monthLabel(filters.month), reset: 'all' });
    }
    if (filters.specialty && filters.specialty !== 'all') {
      out.push({ key: 'specialty', label: filters.specialty, reset: 'all' });
    }
    VISUAL_FILTER_KEYS.forEach((k) => {
      if (filters[k]) {
        out.push({ key: k, label: CHIP_LABELS[k](filters[k]), reset: null });
      }
    });
    return out;
  }, [filters]);

  const removeChip = (key, reset) => setFilters({ ...filters, [key]: reset });

  // Visual cross-filters (city / gender / insurance) live in state as either
  // a specific value or `null`. Dropdowns need a string, so we normalise
  // `null` ↔ `'all'` at the boundary.
  const dropdownValue = (key) => filters[key] || 'all';
  const setDropdown = (key) => (v) => setFilters({ ...filters, [key]: v === 'all' ? null : v });

  return (
    <div
      className="sticky top-0 z-30 backdrop-blur-xl border-b px-4 md:px-8 py-4"
      style={{ background: t.bg + 'D9', borderColor: t.line }}
    >
      <div className="flex flex-wrap items-end gap-3 justify-between">
        <div className="flex flex-wrap items-end gap-3">
          <Select
            label="Period"
            value={filters.month}
            onChange={(v) => setFilters({ ...filters, month: v })}
            options={monthOptions}
          />
          <Select
            label="Specialty"
            value={filters.specialty}
            onChange={(v) => setFilters({ ...filters, specialty: v })}
            options={[
              { value: 'all', label: 'All Specialties' },
              ...SPECIALTIES.map((s) => ({ value: s, label: s })),
            ]}
          />
          <Select
            label="City"
            value={dropdownValue('city')}
            onChange={setDropdown('city')}
            options={[
              { value: 'all', label: 'All Cities' },
              ...CITIES.map((c) => ({ value: c, label: c })),
            ]}
          />
          <Select
            label="Insurance"
            value={dropdownValue('insurance')}
            onChange={setDropdown('insurance')}
            options={[
              { value: 'all', label: 'All Insurers' },
              ...INSURERS.map((i) => ({ value: i, label: i })),
            ]}
          />
          <Select
            label="Gender"
            value={dropdownValue('gender')}
            onChange={setDropdown('gender')}
            options={[
              { value: 'all', label: 'All Genders' },
              { value: 'F', label: 'Female' },
              { value: 'M', label: 'Male' },
            ]}
          />
        </div>
        <div className="flex items-end gap-2">
          <button
            type="button"
            onClick={onCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-all hover:opacity-80"
            style={{ background: t.panel, borderColor: t.line, color: t.inkSoft }}
          >
            <Download size={13} /> CSV
          </button>
          {activeChips.length > 0 && (
            <button
              type="button"
              onClick={() => setFilters(clearVisualFilters(filters))}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-all hover:opacity-80"
              style={{ background: t.accent + '15', borderColor: t.accent + '40', color: t.accent }}
            >
              <Trash2 size={13} /> Clear Visual Filters
            </button>
          )}
        </div>
      </div>

      <AnimatePresence>
        {activeChips.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-wrap gap-2 mt-3"
          >
            <span
              className="text-[10px] uppercase mt-1.5"
              style={{ color: t.inkMuted, letterSpacing: '0.15em' }}
            >
              Filters
            </span>
            <AnimatePresence>
              {activeChips.map((c) => (
                <Chip key={c.key} label={c.label} onRemove={() => removeChip(c.key, c.reset)} />
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
