import { createContext, useContext } from 'react';

// Editorial healthcare palette — warm cream + ink + sage + coral.
// Deliberately not the generic SaaS purple-blue gradient.
export const PALETTE = {
  light: {
    bg: '#F4F1EA',
    panel: '#FBF9F4',
    panelMuted: '#EFE9DC',
    ink: '#1A2530',
    inkSoft: '#4A5460',
    inkMuted: '#8A8275',
    line: '#D9D2BF',
    primary: '#3D6655',
    primarySoft: '#7FA38D',
    accent: '#D9603F',
    accent2: '#C2A046',
    accent3: '#5F7FAA',
    accent4: '#8B5A8A',
    success: '#5A8A6A',
    warning: '#C99B3D',
    danger: '#B8463A',
  },
  dark: {
    bg: '#13181E',
    panel: '#1B232B',
    panelMuted: '#222C36',
    ink: '#EDE6D3',
    inkSoft: '#B5AE9D',
    inkMuted: '#6F6A5E',
    line: '#2C3640',
    primary: '#7FA38D',
    primarySoft: '#3D6655',
    accent: '#E07A5F',
    accent2: '#D4B870',
    accent3: '#7F9FCA',
    accent4: '#A878A6',
    success: '#7FA38D',
    warning: '#D4B870',
    danger: '#D17560',
  },
};

export const ThemeContext = createContext(null);
export const useTheme = () => useContext(ThemeContext);
