// Domain constants for the healthcare dataset.
// Pulled from the Vitalis Healthcare Project schema.

export const CITIES = ['Seattle', 'Portland', 'Tacoma', 'Spokane', 'Olympia'];

export const SPECIALTIES = [
  'Cardiology', 'Orthopedics', 'Oncology',
  'Neurology', 'Pediatrics', 'Endocrinology', 'General Medicine'
];

export const INSURERS = ['BlueShield', 'Aetna', 'Medicare', 'Tricare', 'Kaiser'];

export const STATUSES = ['Completed', 'Cancelled', 'No-show'];

export const PAYMENT_TYPES = ['Insurance', 'Card', 'Cash'];

// ICD-10 diagnoses present in the source data
export const DIAGNOSES = [
  { code: 'I10', label: 'Hypertension' },
  { code: 'E11', label: 'Type 2 Diabetes' },
  { code: 'E03', label: 'Hypothyroidism' },
  { code: 'G43', label: 'Migraine' },
  { code: 'R07', label: 'Chest pain' },
  { code: 'I20', label: 'Angina' },
];

export const DOCTORS = [
  'Dr. Adams', 'Dr. Baker', 'Dr. Chen', 'Dr. Diaz', 'Dr. Evans',
  'Dr. Fischer', 'Dr. Gupta', 'Dr. Hayes', 'Dr. Iverson', 'Dr. Johnson'
];

export const FIRST_NAMES = [
  'Alice', 'Bob', 'Carol', 'David', 'Eve', 'Frank', 'Grace', 'Henry',
  'Iris', 'Jack', 'Karen', 'Leo', 'Mia', 'Noah', 'Olivia', 'Peter',
  'Quinn', 'Riley', 'Sam', 'Tara'
];

export const LAST_NAMES = [
  'Smith', 'Jones', 'Brown', 'Davis', 'Wilson',
  'Moore', 'Taylor', 'Anderson', 'Thomas', 'Martin'
];

export const AGE_ORDER = ['Under 18', '18-35', '36-50', '51-65', '65+'];

// Clinical thresholds (American Heart Association + WHO standards)
export const BP_CATEGORIES = [
  { name: 'Normal',          systolic: [0, 120],   diastolic: [0, 80]   },
  { name: 'Elevated',        systolic: [120, 130], diastolic: [0, 80]   },
  { name: 'Stage 1',         systolic: [130, 140], diastolic: [80, 90]  },
  { name: 'Stage 2',         systolic: [140, 180], diastolic: [90, 120] },
  { name: 'Crisis',          systolic: [180, 999], diastolic: [120, 999]},
];

export const BMI_RANGES = [
  { name: 'Underweight', min: 0,    max: 18.5 },
  { name: 'Healthy',     min: 18.5, max: 25   },
  { name: 'Overweight',  min: 25,   max: 30   },
  { name: 'Obese',       min: 30,   max: 999  },
];

export const CHRONIC_CONDITIONS = [
  'Hypertension', 'Diabetes', 'Heart disease', 'Asthma', 'None'
];
