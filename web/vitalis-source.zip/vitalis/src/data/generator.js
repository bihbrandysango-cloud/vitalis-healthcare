import {
  CITIES, SPECIALTIES, INSURERS, STATUSES, PAYMENT_TYPES,
  DIAGNOSES, DOCTORS, FIRST_NAMES, LAST_NAMES,
  BP_CATEGORIES, BMI_RANGES, CHRONIC_CONDITIONS
} from './constants.js';

// Seeded PRNG — same seed produces the same dataset on every load
function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
}

const SPECIALTY_BASE_REVENUE = {
  Cardiology: 800,
  Orthopedics: 900,
  Oncology: 1200,
  Neurology: 700,
  Pediatrics: 350,
  Endocrinology: 550,
  'General Medicine': 300,
};

// Realistic vitals correlated with age & diagnosis
function generateVitals(age, diagnosis, rnd) {
  // BP: roughly normal-ish, drifts higher with age. Hypertensives get pushed up.
  const ageOffset = (age - 30) * 0.6;
  const hyperBoost = diagnosis === 'Hypertension' ? 25 : (diagnosis === 'Angina' ? 15 : 0);
  const systolic = Math.max(85, Math.round(110 + ageOffset + hyperBoost + (rnd() - 0.5) * 30));
  const diastolic = Math.max(55, Math.round(72 + ageOffset * 0.3 + hyperBoost * 0.5 + (rnd() - 0.5) * 15));

  // BMI: normal-ish curve, diabetics skew higher
  const diabetesBoost = diagnosis === 'Type 2 Diabetes' ? 5 : 0;
  const bmi = Math.max(15, Math.round((22 + diabetesBoost + (rnd() - 0.5) * 9) * 10) / 10);

  // Risk score: 0–100, derived from age + vitals + diagnosis severity
  const dxRisk = { 'Hypertension': 20, 'Type 2 Diabetes': 25, 'Angina': 30, 'Chest pain': 15 }[diagnosis] || 8;
  const ageRisk = Math.min(35, Math.max(0, (age - 30) * 0.7));
  const bpRisk = Math.max(0, (systolic - 120) * 0.5);
  const bmiRisk = bmi > 30 ? 12 : (bmi > 25 ? 6 : 0);
  const risk = Math.min(100, Math.round(ageRisk + dxRisk + bpRisk + bmiRisk + (rnd() - 0.5) * 12));

  // Chronic condition tagged from diagnosis where possible, otherwise from prior
  let chronic;
  if (diagnosis === 'Hypertension') chronic = 'Hypertension';
  else if (diagnosis === 'Type 2 Diabetes') chronic = 'Diabetes';
  else if (diagnosis === 'Angina') chronic = 'Heart disease';
  else chronic = rnd() < 0.35 ? CHRONIC_CONDITIONS[Math.floor(rnd() * 4)] : 'None';

  return { systolic, diastolic, bmi, risk, chronic };
}

export function generateRecords(count = 200, seed = 42) {
  const rnd = seededRandom(seed);
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  const records = [];
  const now = new Date();

  for (let i = 0; i < count; i++) {
    const dayOffset = Math.floor(rnd() * 90);
    const date = new Date(now);
    date.setDate(date.getDate() - dayOffset);

    const age = 4 + Math.floor(rnd() * 85);
    const diagnosis = pick(DIAGNOSES).label;
    const specialty = pick(SPECIALTIES);

    // Status distribution mirrors the source dataset: ~33% each of completed/cancelled/no-show
    const roll = rnd();
    const status = roll < 0.34 ? 'Completed' : (roll < 0.67 ? 'Cancelled' : 'No-show');

    const base = SPECIALTY_BASE_REVENUE[specialty];
    const amount = status === 'Completed' ? Math.round(base * (0.7 + rnd() * 0.8)) : 0;
    const coveragePct = 0.4 + rnd() * 0.55;
    const insuranceCovered = Math.round(amount * coveragePct);
    const patientPaid = amount - insuranceCovered;

    const expense = Math.round(amount * (0.4 + rnd() * 0.2)); // synthetic clinic-side cost

    const vitals = generateVitals(age, diagnosis, rnd);

    records.push({
      id: `rec_${seed}_${i}`,
      patient: `${pick(FIRST_NAMES)} ${pick(LAST_NAMES)}`,
      age,
      gender: rnd() < 0.51 ? 'F' : 'M',
      diagnosis,
      date: date.toISOString().slice(0, 10),
      doctor: pick(DOCTORS),
      city: pick(CITIES),
      specialty,
      amount,
      expense,
      insuranceCovered,
      patientPaid,
      insurance: pick(INSURERS),
      paymentType: pick(PAYMENT_TYPES),
      status,
      notes: '',
      // Vitals — used by the Patient Health Profile section
      systolic: vitals.systolic,
      diastolic: vitals.diastolic,
      bmi: vitals.bmi,
      riskScore: vitals.risk,
      chronicCondition: vitals.chronic,
    });
  }
  return records;
}

// Classify a record into clinical buckets
export function bpCategory(systolic, diastolic) {
  if (systolic >= 180 || diastolic >= 120) return 'Crisis';
  if (systolic >= 140 || diastolic >= 90) return 'Stage 2';
  if (systolic >= 130 || diastolic >= 80) return 'Stage 1';
  if (systolic >= 120) return 'Elevated';
  return 'Normal';
}

export function bmiCategory(bmi) {
  for (const r of BMI_RANGES) {
    if (bmi >= r.min && bmi < r.max) return r.name;
  }
  return 'Unknown';
}

export function riskSegment(score) {
  if (score < 25) return 'Low';
  if (score < 50) return 'Moderate';
  if (score < 75) return 'High';
  return 'Critical';
}
