import { useState } from 'react';
import { Download, Trash2, Sun, Moon } from 'lucide-react';
import { useTheme } from '../store/theme.js';
import { generateRecords } from '../data/generator.js';
import { downloadJSON } from '../utils/csv.js';
import Panel from '../components/Panel.jsx';
import Toggle from '../components/Toggle.jsx';

function Row({ label, description, action }) {
  const t = useTheme();
  return (
    <div
      className="flex items-center justify-between py-4 border-b last:border-b-0"
      style={{ borderColor: t.line }}
    >
      <div>
        <div className="text-sm font-medium" style={{ color: t.ink }}>{label}</div>
        {description && (
          <div className="text-xs mt-0.5" style={{ color: t.inkMuted }}>{description}</div>
        )}
      </div>
      {action}
    </div>
  );
}

export default function Settings({ records, setRecords, showToast, prefs, setPrefs }) {
  const t = useTheme();
  const [confirmReset, setConfirmReset] = useState(false);

  const exportJSON = () => {
    downloadJSON({ records, prefs }, 'vitalis-data.json');
    showToast('Exported data');
  };

  const importJSON = (ev) => {
    const file = ev.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        if (Array.isArray(data.records)) setRecords(data.records);
        if (data.prefs && typeof data.prefs === 'object') setPrefs(data.prefs);
        showToast('Imported data');
      } catch {
        showToast('Import failed — invalid JSON');
      }
    };
    reader.readAsText(file);
  };

  const resetAll = () => {
    if (!confirmReset) {
      setConfirmReset(true);
      setTimeout(() => setConfirmReset(false), 3000);
      return;
    }
    setRecords(generateRecords(200, 42));
    setConfirmReset(false);
    showToast('All data reset');
  };

  return (
    <div className="flex-1 min-w-0 px-4 md:px-8 py-6 pb-28 md:pb-10 space-y-6 max-w-3xl">
      <div>
        <div
          className="text-[10px] uppercase"
          style={{ color: t.inkMuted, letterSpacing: '0.2em' }}
        >
          Configuration
        </div>
        <h1
          className="text-3xl md:text-4xl mt-1"
          style={{
            color: t.ink,
            fontFamily: '"Fraunces", Georgia, serif',
            fontWeight: 500,
            letterSpacing: '-0.02em',
          }}
        >
          Settings
        </h1>
      </div>

      <Panel title="Appearance">
        <Row
          label="Theme"
          description="Switch between light and dark mode"
          action={
            <div className="flex gap-1 p-1 rounded-lg" style={{ background: t.panelMuted }}>
              {['light', 'dark'].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => t.setMode(m)}
                  className="px-3 py-1 rounded-md text-xs flex items-center gap-1.5"
                  style={{
                    background: t.mode === m ? t.panel : 'transparent',
                    color: t.mode === m ? t.ink : t.inkMuted,
                    fontWeight: t.mode === m ? 600 : 400,
                  }}
                >
                  {m === 'light' ? <Sun size={12} /> : <Moon size={12} />}
                  {m.charAt(0).toUpperCase() + m.slice(1)}
                </button>
              ))}
            </div>
          }
        />
        <Row
          label="Animations"
          description="Disable motion if you prefer a quieter interface"
          action={
            <Toggle
              checked={prefs.animations}
              onChange={(v) => setPrefs({ ...prefs, animations: v })}
              label="Animations"
            />
          }
        />
      </Panel>

      <Panel title="Dashboard preferences">
        <Row
          label="Smart insights"
          description="Show AI-style recommendations on the dashboard"
          action={
            <Toggle
              checked={prefs.insights}
              onChange={(v) => setPrefs({ ...prefs, insights: v })}
              label="Smart insights"
            />
          }
        />
        <Row
          label="Notifications"
          description="Show toast notifications on data changes"
          action={
            <Toggle
              checked={prefs.notifications}
              onChange={(v) => setPrefs({ ...prefs, notifications: v })}
              label="Notifications"
            />
          }
        />
      </Panel>

      <Panel title="Data">
        <Row
          label="Export data"
          description={`Download all ${records.length} records as JSON`}
          action={
            <button
              type="button"
              onClick={exportJSON}
              className="px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5"
              style={{ background: t.panelMuted, color: t.inkSoft, border: `1px solid ${t.line}` }}
            >
              <Download size={12} /> Export
            </button>
          }
        />
        <Row
          label="Import data"
          description="Load records from a previously exported JSON file"
          action={
            <label
              className="px-3 py-1.5 rounded-lg text-xs font-medium cursor-pointer inline-flex"
              style={{ background: t.panelMuted, color: t.inkSoft, border: `1px solid ${t.line}` }}
            >
              Import
              <input type="file" accept=".json" className="hidden" onChange={importJSON} />
            </label>
          }
        />
        <Row
          label="Reset all data"
          description={
            confirmReset
              ? 'Click again to confirm — this cannot be undone'
              : 'Clear all records and restore default demo dataset'
          }
          action={
            <button
              type="button"
              onClick={resetAll}
              className="px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5"
              style={{
                background: confirmReset ? t.danger : t.danger + '15',
                color: confirmReset ? 'white' : t.danger,
                border: `1px solid ${t.danger}${confirmReset ? '' : '40'}`,
              }}
            >
              <Trash2 size={12} /> {confirmReset ? 'Confirm reset' : 'Reset'}
            </button>
          }
        />
      </Panel>

      <div className="text-center text-xs pt-4" style={{ color: t.inkMuted }}>
        Vitalis Health Analytics · v1.0 · Built on the Vitalis Healthcare Project
      </div>
    </div>
  );
}
