import { useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { useTheme } from '../store/theme.js';
import {
  CITIES, SPECIALTIES, INSURERS, STATUSES, PAYMENT_TYPES,
  DIAGNOSES, DOCTORS,
} from '../data/constants.js';
import { generateRecords } from '../data/generator.js';
import Panel from '../components/Panel.jsx';
import RecordsTable from '../components/RecordsTable.jsx';

const blankForm = () => ({
  patient: '',
  age: '',
  gender: 'F',
  diagnosis: DIAGNOSES[0].label,
  date: new Date().toISOString().slice(0, 10),
  doctor: DOCTORS[0],
  city: CITIES[0],
  specialty: SPECIALTIES[0],
  amount: '',
  paymentType: 'Insurance',
  insurance: INSURERS[0],
  status: 'Completed',
  notes: '',
});

export default function AddRecord({ records, setRecords, showToast }) {
  const t = useTheme();
  const [form, setForm] = useState(blankForm());
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.patient.trim()) e.patient = 'Name required';
    if (!form.age || isNaN(+form.age) || +form.age < 0 || +form.age > 120) e.age = 'Valid age required';
    if (form.amount === '' || isNaN(+form.amount) || +form.amount < 0) e.amount = 'Valid amount required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    const amt = +form.amount;
    const covPct = 0.4 + Math.random() * 0.55;
    // We need vitals on user-added records too so they appear on the Health Profile section
    const age = +form.age;
    const baseSystolic = 110 + (age - 30) * 0.6 + (form.diagnosis === 'Hypertension' ? 25 : 0);
    const baseBMI = 22 + (form.diagnosis === 'Type 2 Diabetes' ? 5 : 0);
    const newRec = {
      id: `rec_user_${Date.now()}`,
      ...form,
      age,
      amount: amt,
      expense: Math.round(amt * 0.5),
      insuranceCovered: Math.round(amt * covPct),
      patientPaid: amt - Math.round(amt * covPct),
      systolic: Math.round(baseSystolic),
      diastolic: Math.round(72 + (age - 30) * 0.3),
      bmi: Math.round(baseBMI * 10) / 10,
      riskScore: Math.min(100, Math.max(0, Math.round((age - 30) * 0.7 + (form.diagnosis === 'Hypertension' ? 20 : 8)))),
      chronicCondition:
        form.diagnosis === 'Hypertension' ? 'Hypertension' :
        form.diagnosis === 'Type 2 Diabetes' ? 'Diabetes' :
        form.diagnosis === 'Angina' ? 'Heart disease' : 'None',
    };
    setRecords([newRec, ...records]);
    setForm(blankForm());
    showToast('Record added — dashboards updated');
  };

  const generateDemo = () => {
    const newRecs = generateRecords(10, Date.now() % 99999);
    setRecords([...newRecs, ...records]);
    showToast('Generated 10 demo records');
  };

  const resetDemo = () => {
    setRecords(generateRecords(200, 42));
    showToast('Reset to 60 days demo data');
  };

  // Accepts either a single ID or an array (for bulk-delete via the table header)
  const deleteRecord = (idOrIds) => {
    const idSet = new Set(Array.isArray(idOrIds) ? idOrIds : [idOrIds]);
    setRecords(records.filter((r) => !idSet.has(r.id)));
    const n = idSet.size;
    showToast(n > 1 ? `${n} records deleted` : 'Record deleted');
  };

  const renderField = (field, label, type = 'text', options = null) => {
    const id = `field-${field}`;
    return (
      <div key={field}>
        <label
          htmlFor={id}
          className="block text-[10px] uppercase mb-1.5"
          style={{ color: t.inkMuted, letterSpacing: '0.12em' }}
        >
          {label}
        </label>
        {options ? (
          <select
            id={id}
            value={form[field]}
            onChange={(e) => setForm({ ...form, [field]: e.target.value })}
            className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
            style={{
              background: t.panel,
              borderColor: t.line,
              color: t.ink,
              colorScheme: t.mode,
            }}
          >
            {options.map((o) => (
              <option key={o} value={o} style={{ background: t.panel, color: t.ink }}>
                {o}
              </option>
            ))}
          </select>
        ) : (
          <input
            id={id}
            type={type}
            value={form[field]}
            onChange={(e) => setForm({ ...form, [field]: e.target.value })}
            className="w-full px-3 py-2 rounded-lg text-sm border outline-none"
            style={{
              background: t.panel,
              borderColor: errors[field] ? t.danger : t.line,
              color: t.ink,
            }}
            aria-invalid={!!errors[field]}
          />
        )}
        {errors[field] && (
          <p className="text-[10px] mt-1" style={{ color: t.danger }}>{errors[field]}</p>
        )}
      </div>
    );
  };

  return (
    <div className="flex-1 min-w-0 px-4 md:px-8 py-6 pb-28 md:pb-10 space-y-6">
      <div>
        <div
          className="text-[10px] uppercase"
          style={{ color: t.inkMuted, letterSpacing: '0.2em' }}
        >
          Data Entry
        </div>
        <h1
          className="text-3xl md:text-4xl mt-1"
          style={{
            color: t.ink,
            fontFamily: '"Fraunces", Georgia, serif',
            fontWeight: 500,
            letterSpacing: '-0.02em',
          }}
        >
          Add a new record
        </h1>
      </div>

      <Panel
        title="New patient encounter"
        action={
          <div className="flex gap-2">
            <button
              type="button"
              onClick={generateDemo}
              className="text-xs px-3 py-1.5 rounded-lg border"
              style={{ background: t.panelMuted, borderColor: t.line, color: t.inkSoft }}
            >
              + 10 Demo Records
            </button>
            <button
              type="button"
              onClick={resetDemo}
              className="text-xs px-3 py-1.5 rounded-lg border inline-flex items-center gap-1"
              style={{ background: t.panelMuted, borderColor: t.line, color: t.inkSoft }}
            >
              <RefreshCw size={11} /> Reset 60d
            </button>
          </div>
        }
      >
        <form onSubmit={submit} className="grid md:grid-cols-3 gap-4">
          {renderField('patient', 'Patient Name')}
          {renderField('age', 'Age', 'number')}
          {renderField('gender', 'Gender', 'text', ['F', 'M'])}
          {renderField('diagnosis', 'Diagnosis', 'text', DIAGNOSES.map((d) => d.label))}
          {renderField('date', 'Appointment Date', 'date')}
          {renderField('doctor', 'Doctor', 'text', DOCTORS)}
          {renderField('city', 'Clinic Location', 'text', CITIES)}
          {renderField('specialty', 'Specialty', 'text', SPECIALTIES)}
          {renderField('amount', 'Revenue Amount ($)', 'number')}
          {renderField('paymentType', 'Payment Type', 'text', PAYMENT_TYPES)}
          {renderField('insurance', 'Insurance Provider', 'text', INSURERS)}
          {renderField('status', 'Appointment Status', 'text', STATUSES)}
          <div className="md:col-span-3">
            <label
              htmlFor="field-notes"
              className="block text-[10px] uppercase mb-1.5"
              style={{ color: t.inkMuted, letterSpacing: '0.12em' }}
            >
              Notes
            </label>
            <textarea
              id="field-notes"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={2}
              className="w-full px-3 py-2 rounded-lg text-sm border outline-none resize-none"
              style={{ background: t.panel, borderColor: t.line, color: t.ink }}
            />
          </div>
          <div className="md:col-span-3 flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setForm(blankForm())}
              className="px-4 py-2 rounded-lg text-sm border"
              style={{ borderColor: t.line, color: t.inkSoft, background: 'transparent' }}
            >
              Clear
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg text-sm font-medium"
              style={{ background: t.primary, color: 'white' }}
            >
              Add Record
            </button>
          </div>
        </form>
      </Panel>

      <Panel title="Recent records">
        <RecordsTable records={records} onDelete={deleteRecord} />
      </Panel>
    </div>
  );
}
