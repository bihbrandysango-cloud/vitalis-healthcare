import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Users, DollarSign, Calendar, AlertTriangle, Shield, Sparkles } from 'lucide-react';
import { useTheme } from '../store/theme.js';
import { fmtMoney, fmtNum, fmtPct } from '../utils/format.js';
import { downloadCSV } from '../utils/csv.js';
import { useFilteredRecords } from '../hooks/useFilteredRecords.js';
import Panel from '../components/Panel.jsx';
import KpiCard from '../components/KpiCard.jsx';
import FilterBar from '../components/FilterBar.jsx';
import DemographicsRow from '../components/charts/DemographicsRow.jsx';
import FinancialRow from '../components/charts/FinancialRow.jsx';
import DoctorDiagnosisRow from '../components/charts/DoctorDiagnosisRow.jsx';
import AppointmentRow from '../components/charts/AppointmentRow.jsx';
import RevenueByAgeAndDoctor from '../components/charts/RevenueByAgeAndDoctor.jsx';
import HealthProfileRow from '../components/charts/HealthProfileRow.jsx';

export default function Dashboard({ records, filters, setFilters, prefs }) {
  const t = useTheme();
  const filtered = useFilteredRecords(records, filters);

  const kpis = useMemo(() => {
    const totalPatients = new Set(filtered.map((r) => r.patient)).size;
    const totalRevenue  = filtered.reduce((s, r) => s + r.amount, 0);
    const noShowCount   = filtered.filter((r) => r.status === 'No-show').length;
    const totalAmount   = totalRevenue;
    const totalInsCov   = filtered.reduce((s, r) => s + r.insuranceCovered, 0);
    return {
      totalPatients,
      totalRevenue,
      appointmentCount: filtered.length,
      noShowRate: filtered.length ? noShowCount / filtered.length : 0,
      coveragePct: totalAmount ? totalInsCov / totalAmount : 0,
    };
  }, [filtered]);

  // Smart insights — surface 2-3 actionable observations
  const insights = useMemo(() => {
    if (!filtered.length) return [];
    const tips = [];
    const noShowPct = kpis.noShowRate * 100;

    // Find top clinic
    const cityRev = new Map();
    filtered.forEach((r) => cityRev.set(r.city, (cityRev.get(r.city) || 0) + r.amount));
    const topCity = [...cityRev.entries()].sort((a, b) => b[1] - a[1])[0];
    if (topCity && topCity[1] > 0) {
      tips.push(`${topCity[0]} is your top-grossing clinic at ${fmtMoney(topCity[1])} this period.`);
    }

    // Find top specialty
    const specRev = new Map();
    filtered.forEach((r) => specRev.set(r.specialty, (specRev.get(r.specialty) || 0) + r.amount));
    const topSpec = [...specRev.entries()].sort((a, b) => b[1] - a[1])[0];
    if (topSpec && topSpec[1] > 0) {
      tips.push(`${topSpec[0]} drives the most revenue (${fmtMoney(topSpec[1])}); consider expanding capacity.`);
    }

    if (noShowPct > 25) {
      tips.push(`No-show rate is ${noShowPct.toFixed(1)}% — automated SMS reminders typically reduce this by ~30%.`);
    }

    if (kpis.coveragePct > 0 && kpis.coveragePct < 0.6) {
      tips.push(`Insurance covers only ${fmtPct(kpis.coveragePct)} of billed amount on average — review reimbursement contracts.`);
    }

    return tips.slice(0, 3);
  }, [filtered, kpis]);

  const handleCSV = () => downloadCSV(filtered, 'vitalis-records.csv');

  return (
    <div className="flex-1 min-w-0">
      <FilterBar
        records={records}
        filters={filters}
        setFilters={setFilters}
        onCSV={handleCSV}
      />

      <div className="px-4 md:px-8 py-6 pb-28 md:pb-10 space-y-6">
        {/* Page heading */}
        <div className="flex items-end justify-between flex-wrap gap-3">
          <div>
            <div
              className="text-[10px] uppercase"
              style={{ color: t.inkMuted, letterSpacing: '0.2em' }}
            >
              Overview
            </div>
            <h1
              className="text-3xl md:text-4xl mt-1"
              style={{
                color: t.ink,
                fontFamily: '"Fraunces", Georgia, serif',
                fontWeight: 500,
                letterSpacing: '-0.02em',
              }}
            >
              Practice performance, at a glance
            </h1>
          </div>
          <div className="text-xs" style={{ color: t.inkMuted }}>
            {filtered.length.toLocaleString()} records · updated just now
          </div>
        </div>

        {/* KPI Cards — 5 headline metrics */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          <KpiCard icon={Users}          label="Total Patients" value={kpis.totalPatients}    format={fmtNum}    accent={t.primary} />
          <KpiCard icon={DollarSign}     label="Total Revenue"  value={kpis.totalRevenue}     format={fmtMoney}  accent={t.accent} />
          <KpiCard icon={Calendar}       label="Appointments"   value={kpis.appointmentCount} format={fmtNum}    accent={t.accent3} />
          <KpiCard icon={AlertTriangle}  label="No-Show Rate"   value={kpis.noShowRate}       format={fmtPct}    accent={t.danger} />
          <KpiCard icon={Shield}         label="Coverage %"     value={kpis.coveragePct}      format={fmtPct}    accent={t.accent2} />
        </div>

        {/* Smart insights */}
        {prefs.insights && insights.length > 0 && (
          <Panel
            title="Smart insights"
            subtitle="Click any chart element to cross-filter the dashboard"
            action={<Sparkles size={16} style={{ color: t.accent }} />}
          >
            <div className="grid md:grid-cols-3 gap-3">
              {insights.map((tip, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className="px-4 py-3 rounded-xl border-l-2"
                  style={{ borderLeftColor: t.accent, background: t.panelMuted }}
                >
                  <p className="text-sm leading-relaxed" style={{ color: t.inkSoft }}>{tip}</p>
                </motion.div>
              ))}
            </div>
          </Panel>
        )}

        <DemographicsRow         records={filtered} filters={filters} setFilters={setFilters} />
        <FinancialRow            records={filtered} filters={filters} setFilters={setFilters} />
        <DoctorDiagnosisRow      records={filtered} filters={filters} setFilters={setFilters} />
        <AppointmentRow          records={filtered} filters={filters} setFilters={setFilters} />
        <RevenueByAgeAndDoctor   records={filtered} filters={filters} setFilters={setFilters} />

        {/* Page-section divider */}
        <div className="flex items-center gap-3 pt-4">
          <div className="h-px flex-1" style={{ background: t.line }} />
          <span
            className="text-[10px] uppercase"
            style={{ color: t.inkMuted, letterSpacing: '0.2em' }}
          >
            Patient Health Profile
          </span>
          <div className="h-px flex-1" style={{ background: t.line }} />
        </div>

        <HealthProfileRow records={filtered} filters={filters} setFilters={setFilters} />
      </div>
    </div>
  );
}
