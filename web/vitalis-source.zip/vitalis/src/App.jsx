import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Sun, Moon, Stethoscope } from 'lucide-react';

import { PALETTE, ThemeContext } from './store/theme.js';
import { useLocalStorage } from './hooks/useLocalStorage.js';
import { EMPTY_FILTERS } from './hooks/useFilteredRecords.js';
import { generateRecords } from './data/generator.js';

import Sidebar from './components/Sidebar.jsx';
import BottomNav from './components/BottomNav.jsx';
import Toast from './components/Toast.jsx';

import Dashboard from './pages/Dashboard.jsx';
import AddRecord from './pages/AddRecord.jsx';
import Settings from './pages/Settings.jsx';

const DEFAULT_PREFS = {
  animations: true,
  insights: true,
  notifications: true,
};

export default function App() {
  // Persistent state — survives page refreshes
  const [mode, setMode]         = useLocalStorage('vitalis.mode', 'light');
  const [records, setRecords]   = useLocalStorage('vitalis.records', generateRecords(200, 42));
  const [prefs, setPrefs]       = useLocalStorage('vitalis.prefs', DEFAULT_PREFS);
  const [filters, setFilters]   = useLocalStorage('vitalis.filters', EMPTY_FILTERS);

  // Transient state
  const [page, setPage] = useState('dashboard');
  const [toast, setToast] = useState(null);

  // Theme context value with palette + helper setter
  const themeValues = { ...PALETTE[mode], mode, setMode };

  const showToast = (msg) => {
    if (prefs.notifications) setToast({ id: Date.now(), msg });
  };

  // Inject Google Fonts at runtime so the app stays self-contained
  useEffect(() => {
    const id = 'vitalis-fonts';
    if (document.getElementById(id)) return;
    const link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Fraunces:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap';
    document.head.appendChild(link);
  }, []);

  // Reflect mode on <html> so OS-level form controls (date pickers) follow theme
  useEffect(() => {
    document.documentElement.style.colorScheme = mode;
  }, [mode]);

  const pageTransition = prefs.animations
    ? { initial: { opacity: 0, y: 8 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -8 }, transition: { duration: 0.25 } }
    : {};

  return (
    <ThemeContext.Provider value={themeValues}>
      <div
        className="min-h-screen flex"
        style={{
          background: themeValues.bg,
          color: themeValues.ink,
          fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
        }}
      >
        <Sidebar current={page} onNav={setPage} />

        <main className="flex-1 min-w-0 flex flex-col relative">
          {/* Mobile header */}
          <header
            className="md:hidden flex items-center justify-between px-4 py-4 border-b"
            style={{ background: themeValues.panel, borderColor: themeValues.line }}
          >
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: themeValues.primary }}
              >
                <Stethoscope size={15} color="white" />
              </div>
              <div
                className="text-base"
                style={{
                  color: themeValues.ink,
                  fontFamily: '"Fraunces", Georgia, serif',
                  fontWeight: 600,
                }}
              >
                Vitalis
              </div>
            </div>
            <button
              type="button"
              onClick={() => setMode(mode === 'light' ? 'dark' : 'light')}
              className="p-2 rounded-lg"
              style={{ color: themeValues.inkSoft }}
              aria-label="Toggle theme"
            >
              {mode === 'light' ? <Moon size={16} /> : <Sun size={16} />}
            </button>
          </header>

          {/* Desktop theme toggle */}
          <div className="hidden md:flex absolute top-5 right-8 z-40">
            <button
              type="button"
              onClick={() => setMode(mode === 'light' ? 'dark' : 'light')}
              className="p-2 rounded-lg border"
              style={{
                background: themeValues.panel,
                borderColor: themeValues.line,
                color: themeValues.inkSoft,
              }}
              aria-label="Toggle theme"
            >
              {mode === 'light' ? <Moon size={14} /> : <Sun size={14} />}
            </button>
          </div>

          <AnimatePresence mode="wait">
            <motion.div key={page} {...pageTransition} className="flex-1 flex">
              {page === 'dashboard' && (
                <Dashboard
                  records={records}
                  filters={filters}
                  setFilters={setFilters}
                  prefs={prefs}
                />
              )}
              {page === 'add' && (
                <AddRecord
                  records={records}
                  setRecords={setRecords}
                  showToast={showToast}
                />
              )}
              {page === 'settings' && (
                <Settings
                  records={records}
                  setRecords={setRecords}
                  showToast={showToast}
                  prefs={prefs}
                  setPrefs={setPrefs}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        <BottomNav current={page} onNav={setPage} />

        <AnimatePresence>
          {toast && (
            <Toast key={toast.id} message={toast.msg} onClose={() => setToast(null)} />
          )}
        </AnimatePresence>
      </div>
    </ThemeContext.Provider>
  );
}
