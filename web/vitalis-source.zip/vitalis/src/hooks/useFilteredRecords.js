import { useMemo } from 'react';
import { monthKey, ageGroup } from '../utils/format.js';

// Apply the current filter state to the full record list.
// Used by every chart on the dashboard.
export function useFilteredRecords(records, filters) {
  return useMemo(() => {
    return records.filter((r) => {
      if (filters.month && filters.month !== 'all' && monthKey(r.date) !== filters.month) return false;
      if (filters.specialty && filters.specialty !== 'all' && r.specialty !== filters.specialty) return false;
      if (filters.city && r.city !== filters.city) return false;
      if (filters.gender && r.gender !== filters.gender) return false;
      if (filters.insurance && r.insurance !== filters.insurance) return false;
      if (filters.status && r.status !== filters.status) return false;
      if (filters.diagnosis && r.diagnosis !== filters.diagnosis) return false;
      if (filters.ageGroup && ageGroup(r.age) !== filters.ageGroup) return false;
      if (filters.chronic && r.chronicCondition !== filters.chronic) return false;
      return true;
    });
  }, [records, filters]);
}

export const EMPTY_FILTERS = {
  month: 'all',
  specialty: 'all',
  city: null,
  gender: null,
  insurance: null,
  status: null,
  diagnosis: null,
  ageGroup: null,
  chronic: null,
};

// Clear visual cross-filters but keep the top-bar dropdowns (month, specialty)
export const VISUAL_FILTER_KEYS = ['city', 'gender', 'insurance', 'status', 'diagnosis', 'ageGroup', 'chronic'];

export function clearVisualFilters(filters) {
  const out = { ...filters };
  VISUAL_FILTER_KEYS.forEach((k) => { out[k] = null; });
  return out;
}
