import { useEffect, useState } from 'react';

// React state synced to localStorage. Reads on mount, writes on every change.
// Gracefully degrades to in-memory state when localStorage is unavailable
// (e.g. in some sandboxed previewers).
export function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key);
      return stored !== null ? JSON.parse(stored) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // silently ignore quota / sandbox errors
    }
  }, [key, value]);

  return [value, setValue];
}
