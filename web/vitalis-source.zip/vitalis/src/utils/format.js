// Reusable display formatters

export const fmtMoney = (n) => '$' + Math.round(n || 0).toLocaleString();
export const fmtMoneyShort = (n) =>
  Math.abs(n) >= 1000 ? '$' + (n / 1000).toFixed(0) + 'k' : '$' + Math.round(n);
export const fmtNum = (n) => Math.round(n || 0).toLocaleString();
export const fmtPct = (n) => ((n || 0) * 100).toFixed(1) + '%';
export const fmtAge = (n) => Math.round(n || 0) + ' yrs';

export const ageGroup = (age) => {
  if (age < 18) return 'Under 18';
  if (age <= 35) return '18-35';
  if (age <= 50) return '36-50';
  if (age <= 65) return '51-65';
  return '65+';
};

export const monthKey = (dateStr) => (dateStr || '').slice(0, 7);

export const monthLabel = (key) => {
  if (!key || key === 'all') return key;
  const [y, m] = key.split('-');
  return new Date(+y, +m - 1).toLocaleString('en', { month: 'short' }) + ' ' + y.slice(2);
};

export const weekdayShort = (dateStr) => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const d = new Date(dateStr);
  return days[(d.getDay() + 6) % 7];
};
