# Vitalis — Healthcare Analytics

A Power BI-inspired analytics dashboard built on the Vitalis Healthcare Project dataset.

## Quick start

```bash
npm install
npm run dev
```

Then open http://localhost:5173.

## Build for production

```bash
npm run build
npm run preview
```

## Stack

- **React 18** + **Vite 5**
- **Tailwind CSS 3** for styling
- **Recharts 2** for data viz
- **Framer Motion 11** for animation
- **lucide-react** for icons
- **Context API** for theme (Zustand was an alternative — chose Context to keep deps lean)
- **LocalStorage** for persistence via the `useLocalStorage` hook

## Project structure

```
src/
├── App.jsx                    Root: theme provider, page routing, persistence
├── main.jsx                   Vite entry
├── index.css                  Tailwind directives + global styles
│
├── components/                Reusable UI primitives
│   ├── AnimatedNumber.jsx     Counter animation
│   ├── BottomNav.jsx          Mobile bottom navigation
│   ├── ChartTooltip.jsx       Themed Recharts tooltip
│   ├── Chip.jsx               Removable filter chip
│   ├── EmptyState.jsx         Empty-data placeholder
│   ├── FilterBar.jsx          Sticky top filter bar
│   ├── KpiCard.jsx            KPI metric card
│   ├── Panel.jsx              Standard card container
│   ├── RecordsTable.jsx       Searchable/sortable/paginated table
│   ├── Select.jsx             Themed dropdown
│   ├── Sidebar.jsx            Desktop side navigation
│   ├── Skeleton.jsx           Loading placeholder
│   ├── Toast.jsx              Bottom-right notification
│   ├── Toggle.jsx             Animated switch
│   │
│   └── charts/                Per-section chart compositions
│       ├── AppointmentRow.jsx
│       ├── DemographicsRow.jsx
│       ├── DoctorDiagnosisRow.jsx
│       ├── FinancialRow.jsx
│       ├── HealthProfileRow.jsx
│       └── RevenueByAgeAndDoctor.jsx
│
├── pages/                     Top-level pages
│   ├── AddRecord.jsx
│   ├── Dashboard.jsx
│   └── Settings.jsx
│
├── hooks/
│   ├── useLocalStorage.js     useState synced to localStorage
│   └── useFilteredRecords.js  Central filter pipeline + filter helpers
│
├── store/
│   └── theme.js               Theme palette + context
│
├── utils/
│   ├── csv.js                 CSV / JSON export helpers
│   └── format.js              Money / percent / age-group formatters
│
└── data/
    ├── constants.js           Cities, specialties, diagnoses, etc.
    └── generator.js           Seeded record + vitals generator
```

## Features delivered against the brief

| Brief item                                                    | Where it lives                                |
|---------------------------------------------------------------|-----------------------------------------------|
| Dashboard / Add Record / Settings pages                       | `pages/`                                      |
| Desktop sidebar, mobile bottom nav                            | `components/Sidebar.jsx`, `BottomNav.jsx`     |
| Sticky filter bar with chips + clear button                   | `components/FilterBar.jsx`                    |
| 6 KPI cards (Patients, Revenue, Appts, No-show, Coverage, Avg Age) | `pages/Dashboard.jsx`                    |
| Demographics (gender donut, city bar, insurance pie)          | `components/charts/DemographicsRow.jsx`       |
| Financial (revenue trend, by clinic, revenue vs expense)      | `components/charts/FinancialRow.jsx`          |
| Diagnosis (top diagnoses, by specialty, monthly trend)        | `components/charts/DoctorDiagnosisRow.jsx`    |
| Appointments (weekday, status pie, no-show trend)             | `components/charts/AppointmentRow.jsx`        |
| Age-group revenue + doctor efficiency leaderboard             | `components/charts/RevenueByAgeAndDoctor.jsx` |
| Health Profile (BP, BMI, chronic disease, risk score, heatmap)| `components/charts/HealthProfileRow.jsx`      |
| Cross-filtering on chart clicks                               | Every chart calls `setFilters(...)`           |
| Smart insights panel                                          | `pages/Dashboard.jsx`                         |
| Form validation + toasts                                      | `pages/AddRecord.jsx` + `Toast.jsx`           |
| Records table: search, sort, paginate, sticky header, badges  | `components/RecordsTable.jsx`                 |
| Generate 10 demo records / Reset 60d demo                     | `pages/AddRecord.jsx`                         |
| Theme toggle, animation toggle, notifications toggle          | `pages/Settings.jsx`                          |
| Export/import JSON, reset all data                            | `pages/Settings.jsx`                          |
| LocalStorage persistence                                      | `hooks/useLocalStorage.js`                    |
| Dark mode                                                     | `store/theme.js` with full palette            |
| Animated counters, page transitions, chart fade-ins           | Framer Motion throughout                      |
| Empty states & loading skeletons                              | `EmptyState.jsx`, `Skeleton.jsx`              |

## Design choices

- **Editorial palette** — warm cream + ink + sage in light mode, dark slate + cream in dark mode. Deliberately not the generic purple-blue SaaS gradient.
- **Type** — Fraunces (modern serif) for display, Inter for UI. Loaded from Google Fonts at runtime.
- **Layered shadows** — every panel uses two-stop shadows for depth without being heavy.
- **Glassmorphism** — sticky filter bar and mobile bottom-nav use `backdrop-blur-xl` with translucent panel backgrounds.

## Notes on small spec deviations

- **Drag-to-select on trend charts**: Recharts doesn't ship a brush/lasso for date-range selection by default. The month dropdown in the filter bar covers the same use case. To add a real brush, drop `<Brush>` from Recharts into `FinancialRow.jsx`'s revenue chart.
- **Type dropdown (Income/Expense)**: The source dataset only has revenue (positive) entries — there's no expense column in the Vitalis schema. I synthesized a per-record `expense` field for the Revenue-vs-Expense chart. If you want a Type filter, it would gate the dashboard between revenue-side and expense-side views.

## How to extend

- **Add a chart**: drop a new component in `components/charts/`, import it in `pages/Dashboard.jsx`, give it `records / filters / setFilters` props.
- **Add a filter dimension**: extend `EMPTY_FILTERS` in `hooks/useFilteredRecords.js`, add the predicate, add a chip label in `FilterBar.jsx`.
- **Swap Context for Zustand**: `store/theme.js` and the prefs/records useState calls are the only stateful glue. Replace them with a Zustand store and the rest of the app continues working.
